from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os
import fitz  # PyMuPDF for PDF editing

app = FastAPI()

# ✅ Fix CORS issue so frontend can access backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow frontend to connect
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure "pdfs" directory exists
PDF_DIR = "pdfs"
os.makedirs(PDF_DIR, exist_ok=True)

# Load the medical form template
TEMPLATE_PDF = "medical_form.pdf"
UPDATED_PDF = os.path.join(PDF_DIR, "updated_medical_form.pdf")

# Define request models
class TestRequest(BaseModel):
    text: str
    speech: bool

class ConfirmRequest(BaseModel):
    tests: list[str]

# Simulated medical test database (Must match text in the form)
TEST_KEYWORDS = {
    "Glucose": "Glucose Random Fasting",
    "CBC": "CBC",
    "HbA1C": "HbA1C",
    "Creatinine": "Creatinine (eGFR)",
    "Uric Acid": "Uric Acid",
    "Sodium": "Sodium",
    "Potassium": "Potassium",
    "ALT": "ALT",
    "Cholesterol": "Lipid Assessment",
    "Rubella": "Rubella",
    "Pregnancy": "Pregnancy Test (Urine)",
    "Thyroid": "Thyroid",
}

@app.get("/")
async def root():
    return {"message": "Voice Medical Chatbot API is running"}

@app.post("/process")
async def process_text(request: TestRequest):
    text = request.text.strip().lower()
    
    # Detect tests in spoken text
    detected_tests = [word for word in TEST_KEYWORDS if word.lower() in text]

    if not detected_tests:
        return {"reply": "No tests recognized.", "confirmedTest": []}

    return {"reply": f"Detected tests: {', '.join(detected_tests)}", "confirmedTest": detected_tests}

@app.post("/finalize")
async def finalize_tests(request: ConfirmRequest):
    if not request.tests:
        raise HTTPException(status_code=400, detail="No tests provided.")

    try:
        # Open the original PDF
        doc = fitz.open(TEMPLATE_PDF)
        page = doc[0]  # Assuming checkboxes are on the first page

        for test in request.tests:
            if test in TEST_KEYWORDS:
                keyword = TEST_KEYWORDS[test]
                for inst in page.search_for(keyword):
                    # Highlight the detected test instead of checking it off
                    page.add_highlight_annot(inst)

        doc.save(UPDATED_PDF)
        doc.close()

        print(f"✅ Updated PDF Generated: {UPDATED_PDF}")
        return {"message": "PDF Updated", "pdfPath": "updated_medical_form.pdf"}
    except Exception as e:
        print(f"❌ Error updating PDF: {e}")
        raise HTTPException(status_code=500, detail="Failed to update PDF")

@app.get("/pdfs/{filename}")
async def get_pdf(filename: str):
    file_path = os.path.join(PDF_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(file_path, media_type="application/pdf", filename=filename)
